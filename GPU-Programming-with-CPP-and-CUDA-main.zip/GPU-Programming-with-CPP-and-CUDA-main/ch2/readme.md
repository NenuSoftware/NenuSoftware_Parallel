## The original file
As we evolve on the book we changed the Dockerfile that is under .devcontainer, but we kept here the original one for reference.

The change was that originally, for simplicity purposes, we used an NVidia based docker image. Later we changed to an Ubuntu based image in which we installed the CUDA Toolkit for added functionality.