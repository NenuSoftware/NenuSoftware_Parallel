#ifndef VEC_ADD_H
#define VEC_ADD_H

extern "C" {
    void vectorAdd(int *a, int *b, int *c, int N);
}

#endif