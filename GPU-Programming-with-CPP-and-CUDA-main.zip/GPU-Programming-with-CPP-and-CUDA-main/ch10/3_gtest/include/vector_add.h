#ifndef VEC_ADD_H
#define VEC_ADD_H

extern "C" {
    void vectorAdd(float* h_A, float* h_B, float* h_C, int N);
}

#endif