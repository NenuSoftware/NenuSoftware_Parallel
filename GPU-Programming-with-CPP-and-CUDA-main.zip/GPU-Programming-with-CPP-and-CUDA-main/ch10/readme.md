# Introduction

<p>All our examples are numbered here to follow the order in which they appear on the book chapter.</p>

To build the examples we may simply:
 1. create a `build` folder inside of the corresponding code folder
 2. run cmake .. 
 3. run make